<!DOCTYPE html>
<html lang="en-US">
	<head>
		<meta charset="utf-8">
		<meta name="language" content="en-US"/>
		<meta name="description" content="kontaktformular.com"/>
		<meta name="revisit" content="After 7 days"/>
		<meta name="robots" content="noindex"/>
		<title>Data protection</title>
		
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" />

<style type="text/css">
*{
    margin: 0px;
	padding: 0px;
	box-sizing: border-box;
}
body{
	background-color: #FFFFFF;
	padding: 8px;
}

.kontaktformular  {
	 width:  auto;
     margin: 0px 0;
     padding: 10px;
     font-size: 13px;
     font-family: Tahoma, Verdana, Arial;
     border: 0px
     background: #F5F5F5;
     float: left;
     clear: both;
     }

.kontaktformular fieldset {margin: 10px 0;	padding: 8px;}
.kontaktformular a {color: #990000; text-decoration: none;}
.kontaktformular a:hover {color: #483D8A;}
  
.kontaktformular legend {
	 background: #006794;
	 color: #fff;
	 padding: 3px 5px;
	 border: 1px solid #ddd;
	 text-transform: uppercase;
	 }


</style>

	</head>



<body id="Kontaktformularseite">

<div class="kontaktformular">

 <fieldset class="kontaktdaten">
    <legend style="font-size:16px;">Privacy policy</legend>

	

<b style="font-size:16px;">Responsible party:</b><br />
<p style="font-size:16px;padding-top:5px;line-height:1.3;">See imprint</p><br /><br />

<b style="font-size:16px;">Purpose of data collection:</b><br />
<p style="font-size:16px;padding-top:5px;line-height:1.3;">The data collected through this form will be used solely to process your request and will not be shared with third parties.</p><br /><br />

<b style="font-size:16px;">Legal basis:</b><br />
<p style="font-size:16px;padding-top:5px;line-height:1.3;">The processing of your data is based on your consent according to Article 6(1)(a) GDPR.</p><br /><br />

<b style="font-size:16px;">Data retention:</b><br />
<p style="font-size:16px;padding-top:5px;line-height:1.3;">Your data will only be stored for as long as necessary to process your request.</p><br /><br />

<b style="font-size:16px;">Your rights:</b><br />
<p style="font-size:16px;padding-top:5px;line-height:1.3;">You have the right to request information about the data we store about you at any time, and to have it corrected or deleted. For more information, please refer to our privacy policy on our website.</p><br /><br />

<b style="font-size:16px;">Consent:</b><br />
<p style="font-size:16px;padding-top:5px;line-height:1.3;">By submitting the form, you consent to the processing of your data in accordance with this privacy policy.</p>
 
 



		
  </fieldset>

</div>

</body>
</html>