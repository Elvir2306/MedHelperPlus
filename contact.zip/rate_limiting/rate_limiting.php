<?php 

		if($cfg['Rate_Limiting']) { ?>
		  
			<?php

$logFile = 'rate_limiting/log/ip_log.txt';


$visitorIP = $_SERVER['REMOTE_ADDR'];


$logData = file_exists($logFile) ? file_get_contents($logFile) : '';
$ipList = explode("\n", trim($logData));


$ipCount = 0;
foreach ($ipList as $line) {
    if ($line === $visitorIP) {
        $ipCount++;
    }
}


if ($ipCount >= $Maximum_views) {
    echo '<style>
        .centered-container {
            display: flex;
            justify-content: center;
            align-items: center;
            
            margin: 0;
            padding: 20px; 
            box-sizing: border-box; 
        }

        .message-container {
            background-color: #fff;
            padding: 10px;
            border-radius: 10px;
            box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
            text-align: center;
            max-width: 90%;
            width: 100%;
            
            box-sizing: border-box; 
            margin-bottom: 10px; 
        }

        .message {
            color: #d9534f; 
            font-size: 18px;
            line-height:27px;
            font-family: Verdana, sans-serif; 
        }
    </style>
<div class="centered-container">
        <div class="message-container">
            <p><img src="img/failed.png" style="" /></p>
            <p class="message">Unusual activities have been detected.</p>
            <p class="message">The form will be available again shortly.</p>
        </div>
    </div>';
    exit;
    
}


file_put_contents($logFile, $visitorIP . "\n", FILE_APPEND | LOCK_EX);


?>
		  
		  

<?php } 

		
?>		