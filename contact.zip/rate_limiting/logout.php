<?php
session_start();
session_destroy(); 


header("Location: login.php");
exit();


echo "You have been successfully logged out. <a href='login.php'>Back to the login page</a>.";
?>
