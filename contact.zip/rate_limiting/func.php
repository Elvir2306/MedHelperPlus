<?php 
session_start();

include '../config.php';


if ($cfg['Rate_Limiting'] == 1) { 
    
    ?>
     <style>
        .centered-container {
            display: flex;
            justify-content: center;
            align-items: center;
            
            margin: 0;
            padding: 20px; 
            box-sizing: border-box; 
        }

        .message-container {
            background-color: #fff;
            padding: 10px;
            border-radius: 10px;
            box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
            text-align: center;
            max-width: 90%;
            width: 100%;
            
            box-sizing: border-box; 
            margin-bottom: 10px; 
        }

        .message {
            color: green; 
            font-size: 18px;
            font-weight:bold;
            line-height:27px;
            font-family: Verdana, sans-serif; 
        }
    </style>
<div class="centered-container">
        <div class="message-container">
            <p><img src="../img/finished.png" style="" /></p>
            <p class="message">Rate limiting is active.</p>
        </div>
    </div>
    <?php 
} elseif ($cfg['Rate_Limiting'] == 0) { 
    
    ?>
    <style>
        .centered-container {
            display: flex;
            justify-content: center;
            align-items: center;
            
            margin: 0;
            padding: 20px; 
            box-sizing: border-box; 
        }

        .message-container {
            background-color: #fff;
            padding: 10px;
            border-radius: 10px;
            box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
            text-align: center;
            max-width: 90%;
            width: 100%;
            
            box-sizing: border-box; 
            margin-bottom: 10px; 
        }

        .message {
            color: #d9534f; 
            font-size: 18px;
            font-weight:bold;
            line-height:27px;
            font-family: Verdana, sans-serif; 
        }
    </style>
<div class="centered-container">
        <div class="message-container">
            <p><img src="../img/failed.png" style="" /></p>
            <p class="message">Rate limiting is not active.</p>
        </div>
    </div>
    <?php 
} 

?><!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    
</head>


</html>