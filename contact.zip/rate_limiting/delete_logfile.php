<?php

$logFile = 'log/ip_log.txt';


if (file_exists($logFile)) {
    
    file_put_contents($logFile, '', LOCK_EX);
    echo '<div style="font-family: Verdana; color: green; border: 1px solid black; padding: 10px; border-radius: 5px; margin: 20 auto 20px auto; text-align: center; box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); max-width: 90%; width: 390px;line-height:31px;font-size:22px;">The IP log file has been cleared.<br><br>
    <a href="login.php" style="color: blue; text-decoration: underline;font-size:17px;">Back</a></div>';
} else {
    echo '<div style="font-family: Verdana; color: red; border: 1px solid black; padding: 10px; border-radius: 5px; margin: 20 auto 20px auto; text-align: center; box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); max-width: 90%; width: 390px;line-height:31px;font-size:22px;">The IP log file does not exist.<br><br>
    <a href="login.php" style="color: blue; text-decoration: underline;font-size:17px;">Back</a></div>';
}
?><!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete Logfile</title>
    
</head>


</html>