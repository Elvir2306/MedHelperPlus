<?php
session_start();

include '../config.php';


$password = $Password_for_the_login_area;


$error_message = "";


if (isset($_POST['password'])) {
    
    if ($_POST['password'] === $password) {
        $_SESSION['loggedin'] = true;
    } else {
        
        $error_message = '<div style="font-family: Verdana; color: red; border: 1px solid red; padding: 10px; border-radius: 5px; margin: 0 auto 20px auto; text-align: center; box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); max-width: 90%; width: 300px;line-height:23px;">Incorrect password. Please try again.</div>';
    }
}


if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true) {
    
    $logFile = 'log/ip_log.txt';

    
    if (file_exists($logFile)) {
        
        $logData = file_get_contents($logFile);
        
        
        if (trim($logData) === "") {
            echo '<div style="font-family: Verdana; padding: 20px; border-radius: 10px; box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); margin: 20px auto; text-align: center; border: 1px solid #ccc; background-color: #f9f9f9; max-width: 90%; width: 300px;">No entries available.</div>';
        } else {
            
            echo '<div style="font-family: Verdana; font-size:15px; padding: 20px; border-radius: 10px; box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); margin: 20px auto; text-align: center; border: 1px solid #ccc; background-color: #f9f9f9; max-width: 90%; width: 80%;"><pre>' . htmlspecialchars($logData) . '</pre></div>';
        }
    } else {
        
        echo '<div style="font-family: Verdana; color: red; border: 1px solid red; padding: 10px; border-radius: 5px; margin: 20px auto; text-align: center; box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); max-width: 90%; width: 300px;">The log file does not exist.</div>';
    }

    
    echo '<style> a:link, a:visited {
color: #00598D;
text-decoration: none;
font-weight: bold;
}

a:hover {
text-decoration: underline;
} </style>';
    

$file = 'log/ip_log.txt'; 


if (file_exists($file)) {
    
    $fileSize = filesize($file);
    
    
    
    $fileSizeKB = $fileSize / 1024;
    
    
    $fileSizeMB = $fileSize / (1024 * 1024);
    
   
    
    
    
} else {
    
    echo '';
}
    echo '<br /><p style="font-family: Verdana; font-size:19px; padding: 10px; border-radius: 5px; box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); margin: 20px auto; text-align: center; border: 1px solid #ccc; max-width: 90%; width: 200px;">
        <a href="delete_logfile.php" style="color: #007BFF; transition: text-decoration 0.3s; display: inline-block; text-align: center;">Clear log file</a><br /><span style="font-size:14px;line-height:30px;">File size: ' . $fileSize . ' Bytes</span>
    </p><br />';
    


    
    
    echo '<p style="font-family: Verdana; padding: 10px; background-color: #4CAF50; color: white; border-radius: 5px; box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); margin: 20px auto; text-align: center; border: none; max-width: 90%; width: 100px;">
        <a href="logout.php" style="color: white; text-decoration: none;">Logout</a>
    </p>';
} else {
    
    passwordForm($error_message);
}


function passwordForm($error_message) {
    echo '<div style="font-family: Verdana; display: flex; justify-content: center; align-items: center; height: 90vh; flex-direction: column; padding: 0 20px;">';
    
    
    if (!empty($error_message)) {
        echo $error_message;
    }
    
    echo '<form method="post" style="background-color: #f2f2f2; padding: 20px; border-radius: 10px; box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); text-align: center; max-width: 100%; width: 300px;">';
    echo '<h2 style="margin-bottom: 20px;">Open log file</h2>';
    echo '<label for="password" style="display: block; font-weight: bold; margin-bottom: 10px;">Password:</label>';
    
    
    echo '<div style="position: relative; display: flex; align-items: center; justify-content: center;">';
    echo '<input type="password" name="password" id="password" style="padding: 10px; width: calc(100% - 40px); margin-bottom: 20px; border: 1px solid #ccc; border-radius: 5px;" required>';
    
    echo '</div>';
    
    echo '<input type="submit" value="Login" style="padding: 10px 20px; background-color: #4CAF50; color: white; border: none; border-radius: 5px; cursor: pointer; font-size: 16px;">';
    echo '</form>';
    
    echo '<!-- Do NOT remove this copyright notice! -->

<div style="display: flex;justify-content: center;align-items: center;padding-right:5%;padding-left:5%;margin-top:20px;">

<div style="border: 1px solid #ccc; margin: 0;box-sizing: border-box;display: inline-block;line-height: 0.3;vertical-align: top;padding-bottom:7.5px;padding-right:5px;padding-left:5px;">
						<br /><br /><a href="https://www.kontaktformular.com/en" title="kontaktformular.com" style="text-decoration: none;color:#000000;font-size:13.5px;line-height: 20px;" target="_blank">&copy; kontaktformular.com</a>
</div>
</div>
<!-- Do NOT remove this copyright notice! -->'; 
echo '</div>';
    
}
?><!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    
</head>


</html>