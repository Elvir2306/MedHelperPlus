<!DOCTYPE html>
<html lang="en-US">
	<head>
		<meta charset="utf-8">
		<meta name="language" content="en"/>
		<meta name="description" content="kontaktformular.com"/>
		<meta name="revisit" content="After 7 days"/>
		<meta name="robots" content="INDEX,FOLLOW"/>
		<title>kontaktformular.com</title>
	
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" />
<style type="text/css">
body {
font-family:Verdana,Arial,Helvetica,sans-serif;
font-size:15px;
color:#000000;
background-color: #FFFFFF;
        
}

a:link, a:visited, a:active{
color:#000000;
text-decoration:none;
}

a:hover{
text-decoration: underline;
}

        .centered-container {
            display: flex;
            justify-content: center;
            align-items: center;
            margin: 0;
            padding: 20px; /* Abstand zum Rand */
            box-sizing: border-box; /* Einschließen des Paddings in der Höhe und Breite */
        }

        .message-container {
            background-color: #fff;
            padding: 10px;
            border-radius: 10px;
            box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
            text-align: center;
            max-width: 90%;
            width: 100%;
            /* Vermeidung von Überschreitungen auf kleinen Bildschirmen */
            box-sizing: border-box; 
            margin-bottom: 10px; /* Großer Abstand nach unten */
            
        }

        .message {
            color: green; /* Grüne Farbe für Erfolgsmeldung */
            font-size: 19px;
            font-weight:bold;
            line-height:28px;
            font-family: Verdana, sans-serif; /* Schriftart Verdana */
        }     
        
    </style>


	<?php if ($cfg['Do_not_apply_the_iFrame_when_accessing_the_thankyou.php_file']): ?>
    
<script type="text/javascript">
if (top != self)
  top.location = self.location;
</script>
     
<?php endif; ?>
        
	</head>



<body>

<div>

 
  
<div class="centered-container">
        <div class="message-container">
            <p><img src="img/finished.png" style="" /></p>
            <p class="message">Your message has been sent.</p>
           
        </div>
    </div>
	
	
	
	
	
	
	
 

</div>

	

	
</body>
</html>